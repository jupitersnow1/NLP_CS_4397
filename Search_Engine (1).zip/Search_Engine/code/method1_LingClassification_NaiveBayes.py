import argparse
import pickle
import nltk
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import classification_report
import os
import chardet
import re
from nltk.corpus import stopwords

# Ensure required resources are downloaded
nltk.download('stopwords')

# ------------------------ Helper Functions --------------------------

# Function to detect file encoding
def detect_encoding(file_path):
    """
    Detect the encoding of a file using chardet.
    
    Args:
        file_path (str): Path to the file.

    Returns:
        str: Detected encoding (default to 'utf-8-sig' if detection fails).
    """
    with open(file_path, 'rb') as f:
        raw_data = f.read()
        result = chardet.detect(raw_data)
        return result['encoding'] if result['encoding'] else 'utf-8-sig'  # Default to 'utf-8-sig' to handle BOM

# Function to load lexicon (positive and negative word lists)
def load_lexicon(filename):
    """
    Load words from a lexicon file with encoding detection.

    Args:
        filename (str): Path to the lexicon file.

    Returns:
        set: A set of words from the lexicon file.
    """
    lexicon_path = os.path.join('lexicons', filename)  # Adjust path if necessary
    lexicon = set()

    try:
        # Detect encoding dynamically
        encoding = detect_encoding(lexicon_path)
        print(f"Detected encoding for {filename}: {encoding}")

        # Attempt to open the file using the detected encoding, with a fallback to 'utf-8-sig'
        try:
            with open(lexicon_path, 'r', encoding=encoding) as file:
                for line in file:
                    word = line.strip()
                    if word and not word.startswith(';'):  # Exclude comments and empty lines
                        lexicon.add(word)
        except UnicodeDecodeError:
            # In case of a decode error, try 'utf-8-sig' as a fallback
            print(f"Error decoding with {encoding}, trying 'utf-8-sig' instead.")
            with open(lexicon_path, 'r', encoding='utf-8-sig') as file:
                for line in file:
                    word = line.strip()
                    if word and not word.startswith(';'):  # Exclude comments and empty lines
                        lexicon.add(word)
    except FileNotFoundError:
        print(f"Error: The file '{filename}' was not found in the 'lexicons' folder.")
    except Exception as e:
        print(f"Unexpected error while loading {filename}: {e}")
    
    return lexicon

# Function to clean the review text (remove special characters, digits, etc.)
def clean_review(review):
    """Clean the review text."""
    review = re.sub(r'[^A-Za-z\s]', '', review)
    review = review.lower().strip()
    return review

# Function to preprocess review (remove stopwords)
def preprocess_review(review):
    """Tokenize the review, remove stopwords, and apply stemming/lemmatization."""
    stop_words = set(stopwords.words('english'))
    words = review.split()
    words = [word for word in words if word not in stop_words]
    return ' '.join(words)


def filter_reviews(df, aspect1, aspect2, opinion):
    # Use Boolean retrieval to get reviews mentioning both aspect1 and aspect2
    # In this case we are using the AND boolean technique (a1 AND a2 AND opinio)
    matching_reviews = df[
        (df['review_text'].str.contains(aspect1, case=False)) & 
        (df['review_text'].str.contains(aspect2, case=False)) &
        (df['review_text'].str.contains(opinion, case=False))
    ]
    
    # Clean the review_ids: strip surrounding quotes if any
    cleaned_review_ids = [review_id.strip("'").strip('"') for review_id in matching_reviews['review_id'].values]
    
    # Create a DataFrame with review_index column
    review_df = pd.DataFrame(cleaned_review_ids, columns=['review_index'])
    
    return review_df


# ------------------------ Main --------------------------

def main():
    # Parse command-line arguments
    parser = argparse.ArgumentParser(description="Aspect-based Opinion Retrieval")
    parser.add_argument('-a1', '--aspect1', required=True, help="First aspect term (e.g., pizza)")
    parser.add_argument('-a2', '--aspect2', required=True, help="Second aspect term (e.g., taste)")
    parser.add_argument('-o', '--opinion', required=True, help="Opinion term (e.g., great, awful)")
    parser.add_argument('-r', '--reviews', required=True, help="Path to reviews dataset (e.g., reviews_segment.pkl)")
    args = parser.parse_args()

    aspect1 = args.aspect1
    aspect2 = args.aspect2
    opinion = args.opinion
    reviews_path = args.reviews

    # ------------------------ Load Lexicon --------------------------
    # Load lexicons for positive and negative words (optional, you may need them later)
    positive_file = 'positive-words.txt'
    negative_file = 'negative-words.txt'
    
    # Load positive and negative word lists
    positive_words = load_lexicon(positive_file)
    negative_words = load_lexicon(negative_file)

    # ------------------------ Load Dataset --------------------------
    # Load the dataset (this should be the reviews dataset)
    with open(reviews_path, 'rb') as f:
        df = pickle.load(f)

    # ------------------------ Preprocess Data --------------------------
    # Clean and preprocess the reviews
    df['cleaned_review'] = df['review_text'].apply(preprocess_review)
    
    # ------------------------ Filter Reviews --------------------------
    # Filter reviews based on aspect terms and opinion
    matching_review_ids = filter_reviews(df, aspect1, aspect2, opinion)

    # ------------------------ Save Results --------------------------
    # Create output directory if it doesn't exist
    output_dir = os.path.join("..", "output", "pkls_from_4.3_Classification_NaiveBayes")
    os.makedirs(output_dir, exist_ok=True)  # Create directory if it does not exist
    
    # Save the matching review IDs as a .pkl file
    output_filename = os.path.join(output_dir, f'{aspect1}_{aspect2}_{opinion}_NBClassifier.pkl')
    with open(output_filename, 'wb') as f:
        pickle.dump(matching_review_ids, f)
    
    print(f"Matching review IDs have been saved to '{output_filename}'.")

    # ------------------------ Sentiment Classification --------------------------
    # Sentiment Classification (print classification report in the terminal)
    # Convert ratings to numeric and apply sentiment classification
    df['sentiment'] = pd.to_numeric(df['customer_review_rating'], errors='coerce').apply(lambda x: 1 if x > 3 else -1)

    # Vectorize the reviews for classification
    X = df['cleaned_review']
    y = df['sentiment']

    vectorizer = CountVectorizer()
    X_vec = vectorizer.fit_transform(X)

    # Split into train and test sets
    X_train, X_test, y_train, y_test = train_test_split(X_vec, y, test_size=0.2, random_state=42)

    # Train Naive Bayes model
    model = MultinomialNB()
    model.fit(X_train, y_train)

    # Make predictions and evaluate
    y_pred = model.predict(X_test)
    print(classification_report(y_test, y_pred, target_names=["Negative", "Positive"]))

# ------------------------ Run Main --------------------------
if __name__ == "__main__":
    main()



# Notes to self
## how to run: 
## python method1_LingClassification_NaiveBayes.py -a1 cake -a2 taste -o sweeter -r reviews_segment.pkl
## queries: 
## (1) audio quality:poor
## (2) wifi signal:strong 
## (3) gps map:useful 
## (4) image quality:sharp


## create environment: python -m venv method1_environmnet
## activate environment: source method1_environmnet/bin/activate

## run: pip install --upgrade pip
## run: pip install nltk pandas scikit-learn chardet 
## TEST YOUR PROGRAM after installing dependencies!!! 
## pip freeze > requirements_method1
## run (user) pip install -r requirements_method1.txt






##  pip install pandas numpy spacy nltk sklearn scikit-learn 
##  pip install --upgrade pip
##  pip install nltk pandas scikit-learn chardet
