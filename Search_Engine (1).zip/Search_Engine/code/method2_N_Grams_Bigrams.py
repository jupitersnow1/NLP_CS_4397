import argparse
import pandas as pd
import os
import pickle
# from sklearn.feature_extraction.text import CountVectorizer # version 1 : performed not so well 
from sklearn.feature_extraction.text import TfidfVectorizer

import spacy
import nltk
from nltk.corpus import wordnet


# Ensure WordNet data is downloaded
nltk.download('wordnet')
nltk.download('omw-1.4')

# Load spaCy's medium or large language model
nlp = spacy.load("en_core_web_md")

def find_synonyms_with_similarity(word, pos_filter=None, similarity_threshold=0.7): # 0.6 # 0.7 (good)
    """
    Find synonyms for a given word using WordNet and filter them by semantic similarity.
    Args:
        word (str): The word to find synonyms for.
        pos_filter (str): Part of speech filter ('n' for noun, 'a' for adjective).
        similarity_threshold (float): Minimum similarity score to include a synonym.
    Returns:
        list: Filtered list of synonyms.
    """
    synonyms = set()
    original_vector = nlp(word).vector  # Vector for the original word
    
    for syn in wordnet.synsets(word):
        # Apply POS filter if specified
        if pos_filter and syn.pos() != pos_filter:
            continue
        for lemma in syn.lemmas():
            synonym = lemma.name().replace('_', ' ')
            synonym_vector = nlp(synonym).vector
            # Compute similarity if vectors are valid
            if original_vector.any() and synonym_vector.any():
                similarity = nlp(word).similarity(nlp(synonym))
                if similarity >= similarity_threshold:
                    synonyms.add(synonym)
    
    return list(synonyms)

def expand_query(aspect1, aspect2, opinion):
    """
    Expand the query using synonyms filtered by semantic similarity.
    """
    # Restrict to nouns and adjectives based on query context
    aspect1_synonyms = find_synonyms_with_similarity(aspect1, pos_filter='n', similarity_threshold=0.8) # default 0.7 # 0.8 (good)
    aspect2_synonyms = find_synonyms_with_similarity(aspect2, pos_filter='n', similarity_threshold=0.8) # default 0.7 # 0.8 (good)
    opinion_synonyms = find_synonyms_with_similarity(opinion, pos_filter='a', similarity_threshold=0.8) # default 0.7 # 0.8 (good)
    
    # Combine original terms and filtered synonyms
    expanded_terms = list(set([aspect1, aspect2, opinion] + aspect1_synonyms + aspect2_synonyms + opinion_synonyms))
    
    # Optional: Filter out terms not directly related to the main focus
    # expanded_terms = [term for term in expanded_terms if term.lower() in ['peach', 'peaches', 'fruit']]
    
    return " ".join(expanded_terms)




def load_reviews(file_path):
    """Load reviews from a pickle file."""
    try:
        with open(file_path, "rb") as file:
            reviews = pickle.load(file)
        
        # Convert to DataFrame and strip quotes if present in review_id
        df = pd.DataFrame(reviews)
        
        # Strip quotes around review_id (if they are part of the values)
        df['review_id'] = df['review_id'].apply(lambda x: x.strip("'\"") if isinstance(x, str) else x)
        
        print(f"Loaded {len(df)} reviews from {file_path}.")
        return df
    except Exception as e:
        print(f"Error loading reviews: {e}")
        exit(1)


def filter_reviews(reviews_df, query):
    """Filter reviews matching the query and return only the review_id column."""
    vectorizer = TfidfVectorizer(stop_words='english')  # TfidfVectorizer instead of CountVectorizer
    try:
        review_texts = reviews_df['review_text']
        X = vectorizer.fit_transform(review_texts)
        query_vector = vectorizer.transform([query])
        
        # Calculate matching rows using cosine similarity
        matches = (X @ query_vector.T).toarray().flatten()
        
        # Filter reviews where matches > 0 and return only review_id column
        filtered_review_ids = reviews_df[matches > 0]['review_id']
        
        print(f"Found {len(filtered_review_ids)} review_ids matching the query.")
        return filtered_review_ids
    except Exception as e:
        print(f"Error filtering reviews: {e}")
        return pd.Series()


def save_reviews(filtered_reviews, output_path):
    """Save the filtered reviews to a pickle file."""
    try:
        # Get the output directory from the path
        output_dir = os.path.dirname(output_path)

        # Debugging: Print out the directory we're trying to create
        print(f"Checking if directory exists: {output_dir}")

        # Check if the directory exists, if not, create it
        if not os.path.exists(output_dir):
            print(f"Creating directory: {output_dir}")
            os.makedirs(output_dir, exist_ok=True)  # Creates the directory and all parent directories if needed
        
        # Debugging: Verify the directory creation
        if os.path.exists(output_dir):
            print(f"Directory successfully created or already exists: {output_dir}")
        else:
            print(f"Directory creation failed: {output_dir}")
        
        # Saving the data
        with open(output_path, "wb") as file:
            pickle.dump(filtered_reviews.to_dict("records"), file)
        print(f"Relevant reviews saved to {output_path}.")
    except Exception as e:
        print(f"Error saving reviews: {e}")




def main():
    parser = argparse.ArgumentParser(description="Filter reviews based on aspects and opinion.")
    parser.add_argument("-a1", "--aspect1", required=True, help="First aspect (e.g., 'audio').")
    parser.add_argument("-a2", "--aspect2", required=True, help="Second aspect (e.g., 'quality').")
    parser.add_argument("-o", "--opinion", required=True, help="Opinion (e.g., 'poor').")
    parser.add_argument("-r", "--reviews", required=True, help="Path to reviews pickle file.")
    
    args = parser.parse_args()
    
    # Load reviews
    reviews_df = load_reviews(args.reviews)
    
    # Original query
    original_query = f"{args.aspect1} {args.aspect2} {args.opinion}"
    print(f"Original Query: {original_query}")
    
    # Expand query
    expanded_query = expand_query(args.aspect1, args.aspect2, args.opinion)
    print(f"Expanded Query: {expanded_query}")
    
    # Filter reviews (get only review_ids)
    filtered_review_ids = filter_reviews(reviews_df, expanded_query)
    
    # Save relevant review_ids as a DataFrame to a pickle file
    if not filtered_review_ids.empty:
        output_filename = f"{args.aspect1}_{args.aspect2}_{args.opinion}_using_BiGrams.pkl"
        output_path = os.path.join("..", "output", "pkls_from_4.5_N_Grams", output_filename)
        
        # Ensure the output directory exists
        output_dir = os.path.dirname(output_path)
        if not os.path.exists(output_dir):
            print(f"Creating directory: {output_dir}")
            os.makedirs(output_dir, exist_ok=True)  # Creates the directory and all parent directories if needed
        
        try:
            # Create a DataFrame with the review_id column
            review_ids_df = pd.DataFrame(filtered_review_ids, columns=["review_id"])
            
            # Save DataFrame to pickle file
            with open(output_path, "wb") as file:
                pickle.dump(review_ids_df, file)
            print(f"Relevant review_ids saved to {output_path}.")
        except Exception as e:
            print(f"Error saving review_ids: {e}")
    else:
        print("No relevant review_ids found. Nothing to save.")

if __name__ == "__main__":
    main()

## notest to self 
## queries: 
## (1) audio quality:poor (0 results)
## (2) wifi signal:strong (0 results)
## (3) gps map:useful (0 results)
## (4) image quality:sharp (0 result)


######################################## 

# how to run this program, 
## 1. create new environment 
### python -m venv myenv

## 2. activate the virtual environment 
### source myenv/bin/activate

## 3. confirm if in correct environment
### which python
#### should get: (myenv) (base) Jacquelines-MacBook-Pro-2:2_n_gram jacquelinesanchez$ which python 
#####/Users/jacquelinesanchez/Documents/GithubRepositories/UH_2024/NLP_CS_4397/NLP_CS_4397/2_n_gram/myenv/bin/python

## 4. install necessary libraries

### $ pip install pandas numpy spacy scikit-learn nltk
### python -m spacy download en_core_web_md (really important!)

## 5. TEST YOUR PROGRAM !!! ! (DONT SKIP THIS STEP!)
### 

## 6. run
### $ pip freeze > requirements.txt

## 7. install the requirements
### $ pip install -r requirements.txt


## some packages i installed, 
## pip install pandas numpy spacy sklearn nltk 
## python -m spacy download en_core_web_md (really important!)
## $ pip install pandas numpy spacy

