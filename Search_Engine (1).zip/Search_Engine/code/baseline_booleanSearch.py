# this program does not need extranous dependecies
# -------------------------------------
#           Import Libraries
# -------------------------------------
import pandas as pd # 
import argparse #
import os
import json
from tqdm import tqdm #
from collections import defaultdict
import pickle
import re
import nltk #
nltk.download('punkt_tab')
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords

# -------------------------------------
#           Global Variables
# -------------------------------------
stop_words = set(stopwords.words('english'))

# -------------------------------------
#           Tokenizer Function
# -------------------------------------
def tokenize(text):
    """
    Tokenize text and remove stop words.

    Args:
        text (str): The text to tokenize.

    Returns:
        list: List of tokens without stop words.
    """
    tokens = word_tokenize(text.lower())  # tokenize and lowercase the text
    filtered_tokens = [token for token in tokens if token.isalpha() and token not in stop_words]
    return filtered_tokens

# -------------------------------------
#           Index Table Functions
# -------------------------------------
def load_data(file_path):
    """Load review data from a pickle file."""
    with open(file_path, 'rb') as file:
        data = pickle.load(file)
    return data

def create_index(data):
    """
    Creates a global posting list for all unique words in the review data.

    Args:
        data (DataFrame): The review data.

    Returns:
        dict: A dictionary where each word is associated with a list of review IDs.
    """
    index_table = defaultdict(set)
    for idx, row in tqdm(data.iterrows(), total=data.shape[0], desc="Creating global posting list"):
        review_id = re.sub(r"[`'\"“”‘’]+", '', row['review_id'])
        tokens = tokenize(row['review_text'])
        for token in tokens:
            index_table[token].add(review_id)
    index_table = {token: list(review_ids) for token, review_ids in index_table.items()}
    return index_table

def sort_index(index_table):
    """
    Sort the index table by word frequency (most frequent to least frequent)
    and include the list of review IDs.

    Args:
        index_table (dict): The unsorted posting list.

    Returns:
        list: A sorted list of dictionaries.
    """
    sorted_keywords = [
        {
            "keyword": token,
            "frequency": len(review_ids),
            "unique_review_count": len(set(review_ids)),
            "review_ids": list(review_ids)
        }
        for token, review_ids in index_table.items()
    ]
    sorted_keywords.sort(key=lambda x: (-x['frequency'], x['keyword']))
    return sorted_keywords

def save_posting_list(index_table, output_dir):
    """Save the global posting list as a JSON file."""
    json_path = os.path.join(output_dir, 'posting_list.json')
    with open(json_path, 'w') as json_file:
        json.dump(index_table, json_file, indent=4)

def save_sorted_keywords(sorted_keywords, output_dir):
    """Save the sorted keywords with frequencies to a JSON file."""
    json_path = os.path.join(output_dir, 'sorted_keywords.json')
    with open(json_path, 'w') as json_file:
        json.dump(sorted_keywords, json_file, indent=4)

# -------------------------------------
#           Query Methods
# -------------------------------------
def method1(index_table, aspect1, aspect2, opinion):
    """aspect1 OR aspect2 OR opinion."""
    return set(index_table.get(aspect1.lower(), [])) | \
           set(index_table.get(aspect2.lower(), [])) | \
           set(index_table.get(opinion.lower(), []))

def method2(index_table, aspect1, aspect2, opinion):
    """aspect1 AND aspect2 AND opinion."""
    return set(index_table.get(aspect1.lower(), [])) & \
           set(index_table.get(aspect2.lower(), [])) & \
           set(index_table.get(opinion.lower(), []))

def method3(index_table, aspect1, aspect2, opinion):
    """(aspect1 OR aspect2) AND opinion."""
    return (set(index_table.get(aspect1.lower(), [])) | 
            set(index_table.get(aspect2.lower(), []))) & \
           set(index_table.get(opinion.lower(), []))

# -------------------------------------
#           Main Function
# -------------------------------------
def main():
    """Main function to perform the boolean search."""
    parser = argparse.ArgumentParser(description="Perform the boolean search.")
    parser.add_argument("-a1", "--aspect1", type=str, required=True, help="First word of the aspect")
    parser.add_argument("-a2", "--aspect2", type=str, required=True, help="Second word of the aspect")
    parser.add_argument("-o", "--opinion", type=str, required=True, help="Only word of the opinion")
    parser.add_argument("-m", "--method", type=str, required=True, help="Method (method1, method2, method3)")
    parser.add_argument("-r", "--reviews_file", type=str, required=True, help="Path to reviews_segment.pkl")
    args = parser.parse_args()

    # Load data
    review_df = load_data(args.reviews_file)

    # Create and save index table
    index_table = create_index(review_df)
    output_dir = "../output"
    os.makedirs(output_dir, exist_ok=True)
    save_posting_list(index_table, output_dir)
    sorted_keywords = sort_index(index_table)
    save_sorted_keywords(sorted_keywords, output_dir)

    # Perform query
    method = args.method.lower()
    if method == "method1":
        result = method1(index_table, args.aspect1, args.aspect2, args.opinion)
    elif method == "method2":
        result = method2(index_table, args.aspect1, args.aspect2, args.opinion)
    elif method == "method3":
        result = method3(index_table, args.aspect1, args.aspect2, args.opinion)
    else:
        print("Method not supported!")
        return

    # Save results
    cleaned_results = [re.sub(r'[\'"`“”]+', '', review_id) for review_id in result]
    revs = pd.DataFrame({"review_index": cleaned_results})
    # output_file = os.path.join(output_dir, "generated_pickles", f"{args.aspect1}_{args.aspect2}_{args.opinion}_baseline_{args.method}.pkl") # ease the process of finding the spec output for each method 
    output_file = os.path.join(output_dir, "pkls_from_4.1_baseline_method", f"{args.aspect1}_{args.aspect2}_{args.opinion}_baseline_{args.method}.pkl")

    os.makedirs(os.path.dirname(output_file), exist_ok=True)
    revs.to_pickle(output_file)

if __name__ == "__main__":
    main()

# notes to self
## example on how to run the program, 
## python baseline_booleanSearch.py -a1 wifi -a2 signal -o strong -m method1 -r reviews_segment.pkl

# python baseline_booleanSearch.py -a1 oranges -a2 tastes -o sweet -m method1 -r reviews_segment.pkl

## queries: 
## (1) audio quality:poor
## (2) wifi signal:strong 
## (3) gps map:useful 
## (4) image quality:sharp

# create: python -m venv myenv_baseline
# activate: source myenv_baseline/bin/activate
# make sure you are inside the new environment : which python
# run: pip install --upgrade pip

# once inside the environment, install the necessary libraries needed for this program!
## pip install pandas argparse tqdm nltk

## TEST YOUR PROGRAM TO CHECK IF IT WORKS! then you may proceed to freeze (to make sure you are "freezing" the correct dependecies!)

## run: pip freeze > requirements_baseline.txt

## run: pip install -r requirements_baseline.txt


